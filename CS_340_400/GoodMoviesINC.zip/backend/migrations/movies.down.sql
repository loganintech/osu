DROP TABLE `goodmovies`.`movies`
