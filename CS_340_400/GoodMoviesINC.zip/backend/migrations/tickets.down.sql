DROP TABLE `goodmovies`.`tickets`
