DROP TABLE `goodmovies`.`showings`
