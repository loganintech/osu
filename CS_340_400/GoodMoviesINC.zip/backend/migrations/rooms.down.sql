DROP TABLE `goodmovies`.`rooms`
