# Migration Order

## Up
1. Theaters
1. Rooms
1. Movies
1. Customers
1. Showings
1. Tickets


## Down

1. Tickets
1. Showings
1. Customers
1. Movies
1. Rooms
1. Theaters
