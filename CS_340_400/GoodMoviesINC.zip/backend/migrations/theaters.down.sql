DROP TABLE `goodmovies`.`theaters`
