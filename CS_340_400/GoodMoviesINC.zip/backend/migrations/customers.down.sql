DROP TABLE `goodmovies`.`customers`
